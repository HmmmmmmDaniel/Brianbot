import { checkBlacklistStatus } from '../utils/Blacklist';
import {
  Flags,
  SettingsConfigObject,
  getComputedSettings,
} from '../utils/Settings';
import { TextableChannel, Message } from 'oceanic.js';
import { incrementMsgCount, incrementResponseCount } from '../utils/Statistics';
import Lists from '../utils/Lists';

const IM_MATCH = /\b((?:i|l)(?:(?:\'|`|‛|‘|’|′|‵)?m| am)) ([\s\S]*)/i,
  FORMAT_MATCH = /(\*\*?\*?|``?`?|__?|~~|\|\|)+/i,
  SHUT_UP_MATCH = /\b(stfu|shut\s(?:the\s)?(?:fuck\s)?up)\b/i,
  GOODBYE_MATCH = /\b(?:good)? ?bye\b/i;

const IM_RESPONSES = ["Yeah You Are.", "Your Mother?", "Yeah Your Mother Is.", "Nah."];
const SHUT_UP_RESPONSES = ["Nah.", "No I Think You Will."];
const RANDOM_RESPONSES = ["Yeah you are.", "Your Mother.", "Whaaa?"];

// Function to get a random response for IM_MATCH
function getImResponse() {
  return IM_RESPONSES[Math.floor(Math.random() * IM_RESPONSES.length)];
}

// Function to get a random response for SHUT_UP_MATCH
function getShutUpResponse() {
  return SHUT_UP_RESPONSES[Math.floor(Math.random() * SHUT_UP_RESPONSES.length)];
}

// Function to get a random response for other matches
function getRandomResponse() {
  return RANDOM_RESPONSES[Math.floor(Math.random() * RANDOM_RESPONSES.length)];
}

// Function to calculate whether a message has enough uppercase characters to be considered "shouting"
function volumeDown(message: string): boolean {
  let individualCharacters = message.split('').filter((a) => !a.match(/\s/));
  // If the message has no spaces, it's not shouting (probably)
  if (message.indexOf(' ') === -1) return false;
  let uppercaseCharacters = individualCharacters.filter((a) =>
    a.match(/[A-Z]/),
  ).length;
  // If the message has more than 60% uppercase characters, it's shouting
  return uppercaseCharacters / individualCharacters.length >= 0.6;
}

// Function to calculate whether a message should be responded to based on RNG
function doRandom(stuff: SettingsConfigObject): boolean {
  if (!stuff || stuff.RNG === null) return true;
  let r = Math.random();
  if (r <= stuff.RNG) return true;
  return false;
}

// Function to calculate whether a message should be responded to based on 30% chance
function doRandomResponse(): boolean {
  return Math.random() < 0.3;
}

export default async function AutoResponseEvent(msg: Message) {
  // Ignore messages from bots
  if (msg.author.bot) return;
  // Increment the message count for statistics
  incrementMsgCount();
  // Get the settings for the message, and check if the user is blacklisted
  let settings = await getComputedSettings(msg),
    blStatus = await checkBlacklistStatus(msg);

  // If the user is blacklisted, do not respond
  if (blStatus) return;

  // Respond with a random response for any matching pattern
  if (msg.content.match(IM_MATCH)) {
    if (!doRandom(settings.value)) return;
    incrementResponseCount();
    msg.client.rest.channels
      .createMessage(msg.channelID, { content: getImResponse() })
      .catch(() => {});
    return;
  }
  
  if (msg.content.match(SHUT_UP_MATCH)) {
    if (!doRandom(settings.value)) return;
    incrementResponseCount();
    msg.client.rest.channels
      .createMessage(msg.channelID, { content: getShutUpResponse() })
      .catch(() => {});
    return;
  }

  if (msg.content.match(GOODBYE_MATCH)) {
    if (!doRandom(settings.value)) return;
    incrementResponseCount();
    msg.client.rest.channels
      .createMessage(msg.channelID, { content: "Good Luck" })
      .catch(() => {});
    return;
  }

  if (
      msg.content.match(FORMAT_MATCH) ||
      volumeDown(msg.content)
  ) {
    if (!doRandomResponse()) return; // 30% chance to respond
    incrementResponseCount();
    msg.client.rest.channels
      .createMessage(msg.channelID, { content: getRandomResponse() })
      .catch(() => {});
    return;
  }
}
