import FS from 'node:fs';

const lists: {
  pastas: string[];
  jokes: string[];
  ingThings: string[];
  : string[];
  : string[];
  dadsDabbing: string[];
  advice: string[];
  : string[];
  goodbye: string[];
  thanks: string[];
} = JSON.parse(FS.readFileSync('./data/lists.json', 'utf-8'));

export default lists;
