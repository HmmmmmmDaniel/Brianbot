const Github: CommandModule = {
  name: 'github',

  handler:
    "Surprising, didn't expect anyone to look at this, but here you are anyway! Here it is, as well as the other components that aren't built directly into dad, enjoy! https://github.com/AlekEagle/brianbot https://github.com/AlekEagle/brianbot-cluster-manager https://github.com/AlekEagle/brianbot-cluster-client",

  options: {
    description: 'Take a look at the Dad Bot source code!'
  }
};

export default Github;
