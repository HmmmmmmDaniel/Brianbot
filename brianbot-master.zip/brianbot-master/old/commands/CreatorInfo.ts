const CreatorInfo: CommandModule = {
  name: 'creatorinfo',

  handler: "Hmmmmm Daniel",

  options: {
    description: 'Yeah you are'
  }
};

export default CreatorInfo;
