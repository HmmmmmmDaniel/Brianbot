const Advice: CommandModule = {
  name: 'advice',

  async handler(msg, args) {
    const responses = ["No", "Fuck You"];
    return responses[Math.floor(Math.random() * responses.length)];
  },

  options: {
    description: 'Some great advice!'
  }
};

export default Advice;
