import Autoresponse from './Autoresponse';

const events: EventModule[] = [Autoresponse];

export default events;
